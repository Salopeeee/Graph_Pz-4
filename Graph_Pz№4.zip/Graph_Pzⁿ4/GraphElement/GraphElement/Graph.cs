﻿namespace GraphElement
{
    public abstract class Graph
    {
        // Загальні властивості та методи
        public abstract void Draw(); // Припустимо, що у кожного елемента є метод для візуалізації
    }

}
