﻿using System.Drawing;

namespace GraphElement
{
    public abstract class Graph
    {
        public abstract void Draw(Graphics g);
    }
}
